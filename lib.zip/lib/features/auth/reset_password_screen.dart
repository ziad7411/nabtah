import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:nabtah/features/auth/reset_success_screen.dart';
import 'package:nabtah/l10n/app_localizations.dart';

class ResetPasswordScreen extends StatelessWidget {
  final String oobCode;

  ResetPasswordScreen({super.key, required this.oobCode});

  final passwordController = TextEditingController();
  final confirmController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final lang = AppLocalizations.of(context)!;

    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(25),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(lang.resetPasswordTitle,
                    style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 20),
                TextFormField(
                  controller: passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: lang.newPassword,
                  ),
                ),
                const SizedBox(height: 15),
                TextFormField(
                  controller: confirmController,
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: lang.confirmPassword,
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () async {
                    if (passwordController.text !=
                        confirmController.text) {
                      return;
                    }

                    await FirebaseAuth.instance
                        .confirmPasswordReset(
                      code: oobCode,
                      newPassword: passwordController.text,
                    );

                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            const ResetSuccessScreen(),
                      ),
                    );
                  },
                  child: Text(lang.resetPassword),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}