// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get registerTitle => 'Create New Account';

  @override
  String get fullName => 'Full Name';

  @override
  String get email => 'Email';

  @override
  String get phone => 'Phone Number';

  @override
  String get password => 'Password';

  @override
  String get confirmPassword => 'Confirm Password';

  @override
  String get createAccount => 'Create Account';

  @override
  String get alreadyHaveAccount => 'Already have an account? ';

  @override
  String get passwordNotMatch => 'Passwords do not match';

  @override
  String get accountCreated => 'Account created successfully';

  @override
  String get loginTitle => 'Login';

  @override
  String get emailHint => 'Enter your email';

  @override
  String get passwordHint => 'Enter your password';

  @override
  String get forgotPassword => 'Forgot password?';

  @override
  String get loginButton => 'Login';

  @override
  String get noAccount => 'Don\'t have an account?';

  @override
  String get registerNow => 'Register now';

  @override
  String get loginSuccess => 'Logged in successfully';

  @override
  String get sendResetLink => 'Send reset link';

  @override
  String get emailSentSuccess => 'Password reset email sent successfully';

  @override
  String get backToLogin => 'Back to login';

  @override
  String get resetPasswordTitle => 'Reset Password';

  @override
  String get newPassword => 'New Password';

  @override
  String get resetPassword => 'Reset Password';

  @override
  String get passwordResetSuccess => 'Your password has been reset successfully';
}
